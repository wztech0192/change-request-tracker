# change-request-viewer
This is a java desktop application used to view

## Getting Started

* Install Java version 8.0 or higher


## Features

* Login user
* View change requests
* Search, sort, and filter change requests
* View change request content, message, and history
* Send change request message
* As admin, adjust change request status



## Authors

* **Wei Zheng** - *Initial work* 

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details


